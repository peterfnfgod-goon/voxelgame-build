#include "player.h"
#include <math.h>

void Player_Init(Player* p, float x, float y, float z) {
    p->x = x; p->y = y; p->z = z;
    p->yaw = 0; p->pitch = 0;
    p->health = 20.0f;
    p->hunger = 20.0f;
    p->vy = 0;
    p->onGround = 0;
}

/* True if a PLAYER_RADIUS x PLAYER_HEIGHT box centered at (x,z) with feet at
 * y overlaps any physics-solid block. Checks every block cell the box could
 * touch (usually just 1-4 of them since the player is smaller than a
 * block). */
static int playerCollides(Chunk* world, float x, float y, float z) {
    int bx0 = (int)floorf(x - PLAYER_RADIUS);
    int bx1 = (int)floorf(x + PLAYER_RADIUS);
    int bz0 = (int)floorf(z - PLAYER_RADIUS);
    int bz1 = (int)floorf(z + PLAYER_RADIUS);
    int by0 = (int)floorf(y);
    int by1 = (int)floorf(y + PLAYER_HEIGHT - 0.01f);

    for (int bx = bx0; bx <= bx1; bx++) {
        for (int bz = bz0; bz <= bz1; bz++) {
            for (int by = by0; by <= by1; by++) {
                if (World_IsSolidForPhysics(world, bx, by, bz)) return 1;
            }
        }
    }
    return 0;
}

void Player_Move(Player* p, Chunk* world, float forward, float strafe, float dt) {
    float speed = 4.3f * dt; /* ~walking pace in blocks/sec */
    float fx = sinf(p->yaw), fz = -cosf(p->yaw);
    float sx = cosf(p->yaw), sz = sinf(p->yaw);
    float dx = (fx * forward + sx * strafe) * speed;
    float dz = (fz * forward + sz * strafe) * speed;

    /* Move on each axis separately and only commit the move if it doesn't
     * collide - this is what gives the "slide along the wall" feel instead
     * of getting fully stuck the moment one axis would clip a block. */
    float newX = p->x + dx;
    if (!playerCollides(world, newX, p->y, p->z)) p->x = newX;

    float newZ = p->z + dz;
    if (!playerCollides(world, p->x, p->y, newZ)) p->z = newZ;
}

void Player_Look(Player* p, float dYaw, float dPitch) {
    p->yaw += dYaw;
    p->pitch += dPitch;
    if (p->pitch > 1.4f) p->pitch = 1.4f;
    if (p->pitch < -1.4f) p->pitch = -1.4f;
}

void Player_UpdatePhysics(Player* p, Chunk* world, float dt, int jumpPressed) {
    if (p->onGround && jumpPressed) {
        p->vy = PLAYER_JUMP_SPEED;
        p->onGround = 0;
    }

    p->vy -= PLAYER_GRAVITY * dt;
    if (p->vy < PLAYER_TERMINAL_VY) p->vy = PLAYER_TERMINAL_VY;

    /* Sub-step the vertical move in small slices rather than one big jump:
     * at typical fall speeds and a 1/60s frame this avoids tunneling
     * through a one-block-thick floor, and lets us stop exactly at the
     * first slice that would collide (used to set onGround precisely). */
    const int steps = 4;
    float totalDelta = p->vy * dt;
    float stepDelta = totalDelta / steps;
    p->onGround = 0;

    for (int i = 0; i < steps; i++) {
        float newY = p->y + stepDelta;
        if (playerCollides(world, p->x, newY, p->z)) {
            if (stepDelta < 0) p->onGround = 1; /* hit the ground */
            p->vy = 0;                          /* hit ground or ceiling either way */
            break;
        }
        p->y = newY;
    }
}
