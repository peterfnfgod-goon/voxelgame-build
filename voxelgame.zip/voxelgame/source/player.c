#include "player.h"
#include <math.h>

void Player_Init(Player* p, float x, float y, float z) {
    p->x = x; p->y = y; p->z = z;
    p->yaw = 0; p->pitch = 0;
    p->health = 20.0f;
    p->hunger = 20.0f;
}

void Player_Move(Player* p, float forward, float strafe, float dt) {
    float speed = 3.0f * dt;
    float fx = sinf(p->yaw), fz = -cosf(p->yaw);
    float sx = cosf(p->yaw), sz = sinf(p->yaw);
    p->x += (fx * forward + sx * strafe) * speed;
    p->z += (fz * forward + sz * strafe) * speed;
}

void Player_Look(Player* p, float dYaw, float dPitch) {
    p->yaw += dYaw;
    p->pitch += dPitch;
    if (p->pitch > 1.4f) p->pitch = 1.4f;
    if (p->pitch < -1.4f) p->pitch = -1.4f;
}
