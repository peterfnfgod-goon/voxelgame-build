#include "mob.h"
#include <string.h>
#include <math.h>
#include <stdlib.h>

void Mob_InitManager(MobManager* mgr) {
    memset(mgr, 0, sizeof(MobManager));
}

int Mob_Spawn(MobManager* mgr, MobType type, float x, float y, float z) {
    if (mgr->count >= MAX_MOBS) return -1;
    Mob* m = &mgr->mobs[mgr->count];
    m->type = type;
    m->alive = 1;
    m->x = x; m->y = y; m->z = z;
    m->vx = 0; m->vy = 0; m->vz = 0;
    switch (type) {
        case MOB_SHAMBLER: m->health = 20.0f; break;
        case MOB_FLYER:    m->health = 12.0f; break;
        case MOB_BRUTE:    m->health = 40.0f; break;
        default:           m->health = 10.0f; break; /* animal */
    }
    m->wanderTimer = 0;
    m->attackCooldown = 0;
    m->state = AI_WANDER;
    mgr->count++;
    return mgr->count - 1;
}

static float frand() { return (rand() % 1000) / 1000.0f; }

void Mob_Update(MobManager* mgr, Chunk* chunk, float playerX, float playerY, float playerZ,
                float dt, int isNight, float* outDamageToPlayer) {
    (void)chunk; /* reserved for future collision/pathing against terrain */
    if (outDamageToPlayer) *outDamageToPlayer = 0.0f;

    for (int i = 0; i < mgr->count; i++) {
        Mob* m = &mgr->mobs[i];
        if (!m->alive) continue;

        float dx = playerX - m->x;
        float dz = playerZ - m->z;
        float dist = sqrtf(dx*dx + dz*dz);

        if (m->type == MOB_ANIMAL) {
            /* Passive: wander randomly, flee a little if player is very close */
            m->wanderTimer -= dt;
            if (dist < 2.0f) {
                m->vx = -dx / (dist + 0.001f) * 1.2f;
                m->vz = -dz / (dist + 0.001f) * 1.2f;
            } else if (m->wanderTimer <= 0) {
                float angle = frand() * 6.2831f;
                m->vx = cosf(angle) * 0.4f;
                m->vz = sinf(angle) * 0.4f;
                m->wanderTimer = 2.0f + frand() * 3.0f;
            }
        } else if (m->type == MOB_SHAMBLER) {
            /* Hostile: only active/aggressive at night or when player is close,
             * mirroring a day/night threat curve without copying any specific
             * game's mob behavior. */
            int aggressive = isNight || dist < 5.0f;

            if (aggressive && dist < 8.0f) {
                m->state = (dist < 1.2f) ? AI_ATTACK : AI_CHASE;
            } else {
                m->state = AI_WANDER;
            }

            switch (m->state) {
                case AI_CHASE:
                    m->vx = dx / (dist + 0.001f) * 0.9f;
                    m->vz = dz / (dist + 0.001f) * 0.9f;
                    break;
                case AI_ATTACK:
                    m->vx = 0; m->vz = 0;
                    if (m->attackCooldown <= 0) {
                        if (outDamageToPlayer) *outDamageToPlayer += 2.0f;
                        m->attackCooldown = 1.0f;
                    }
                    break;
                default: /* wander */
                    m->wanderTimer -= dt;
                    if (m->wanderTimer <= 0) {
                        float angle = frand() * 6.2831f;
                        m->vx = cosf(angle) * 0.25f;
                        m->vz = sinf(angle) * 0.25f;
                        m->wanderTimer = 2.0f + frand() * 3.0f;
                    }
                    break;
            }
        } else if (m->type == MOB_FLYER) {
            /* Erratic flyer: always active, swoops toward the player from
             * the air with a wobble, low damage but hard to pin down. */
            float wobble = sinf((float)i * 1.7f + m->wanderTimer * 3.0f) * 0.6f;
            if (dist < 6.0f) {
                m->state = (dist < 1.0f) ? AI_ATTACK : AI_CHASE;
            } else {
                m->state = AI_WANDER;
            }
            float targetY = playerY + 1.5f;
            float dy = targetY - m->y;

            switch (m->state) {
                case AI_CHASE:
                    m->vx = (dx / (dist + 0.001f)) * 1.1f + wobble * 0.3f;
                    m->vz = (dz / (dist + 0.001f)) * 1.1f - wobble * 0.3f;
                    m->vy = dy * 0.5f;
                    break;
                case AI_ATTACK:
                    m->vx *= 0.5f; m->vz *= 0.5f;
                    if (m->attackCooldown <= 0) {
                        if (outDamageToPlayer) *outDamageToPlayer += 1.0f;
                        m->attackCooldown = 0.8f;
                    }
                    break;
                default:
                    m->wanderTimer -= dt;
                    m->vy = sinf(m->wanderTimer) * 0.3f;
                    if (m->wanderTimer <= 0) {
                        float angle = frand() * 6.2831f;
                        m->vx = cosf(angle) * 0.6f;
                        m->vz = sinf(angle) * 0.6f;
                        m->wanderTimer = 1.0f + frand() * 2.0f;
                    }
                    break;
            }
        } else if (m->type == MOB_BRUTE) {
            /* Tougher, slower melee threat - meant to be a rarer, scarier
             * encounter than the shambler, with a longer "wind-up" before
             * each hit so it telegraphs and is fair to fight. */
            int aggressive = isNight || dist < 4.0f;
            if (aggressive && dist < 9.0f) {
                m->state = (dist < 1.5f) ? AI_ATTACK : AI_CHASE;
            } else {
                m->state = AI_WANDER;
            }

            switch (m->state) {
                case AI_CHASE:
                    m->vx = dx / (dist + 0.001f) * 0.6f; /* slower than shambler */
                    m->vz = dz / (dist + 0.001f) * 0.6f;
                    break;
                case AI_ATTACK:
                    m->vx = 0; m->vz = 0;
                    if (m->attackCooldown <= 0) {
                        if (outDamageToPlayer) *outDamageToPlayer += 5.0f; /* hits hard */
                        m->attackCooldown = 1.6f; /* but slowly */
                    }
                    break;
                default:
                    m->wanderTimer -= dt;
                    if (m->wanderTimer <= 0) {
                        float angle = frand() * 6.2831f;
                        m->vx = cosf(angle) * 0.15f;
                        m->vz = sinf(angle) * 0.15f;
                        m->wanderTimer = 3.0f + frand() * 3.0f;
                    }
                    break;
            }
        }

        if (m->attackCooldown > 0) m->attackCooldown -= dt;

        m->x += m->vx * dt;
        m->z += m->vz * dt;
        if (m->type == MOB_FLYER) {
            m->y += m->vy * dt;
            if (m->y < 5.0f) m->y = 5.0f; /* keep flyers above ground roughly */
        }
    }
}

void Mob_GetColor(MobType type, float* r, float* g, float* b) {
    switch (type) {
        case MOB_ANIMAL:   *r = 0.85f; *g = 0.75f; *b = 0.55f; break; /* light tan critter */
        case MOB_SHAMBLER: *r = 0.25f; *g = 0.45f; *b = 0.20f; break; /* sickly green */
        case MOB_FLYER:    *r = 0.55f; *g = 0.20f; *b = 0.55f; break; /* purple, stands out airborne */
        case MOB_BRUTE:    *r = 0.35f; *g = 0.18f; *b = 0.15f; break; /* dark rust, looks heavy/tough */
        default:           *r = 1; *g = 1; *b = 1; break;
    }
}
