#include "network.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/* Small fixed packet: [0]=playerSlot, then 4 floats packed as bytes via memcpy.
 * Kept deliberately tiny and simple rather than a generic serializer, since
 * this is meant to be a clear starting point you extend, not a final
 * protocol. */
typedef struct {
    u8 slot;
    float x, y, z, yaw;
} __attribute__((packed)) NetPacket;

static u8* s_udsBuffer = NULL;
#define UDS_BUFFER_SIZE 0x4000

int Net_Host(NetSession* session, const char* sessionName) {
    memset(session, 0, sizeof(NetSession));

    Result res = udsInit(NULL, NULL);
    if (R_FAILED(res)) return -1;

    s_udsBuffer = (u8*)malloc(UDS_BUFFER_SIZE);
    if (!s_udsBuffer) { udsExit(); return -1; }

    u8 appData[NET_APPDATA_SIZE] = {1, 0, 0, 0}; /* version byte, room for more */

    res = udsGenerateDefaultNetworkStruct(&session->network, 0x4D43 /* arbitrary game id, change as needed */,
                                           0, NET_MAX_PEERS);
    if (R_FAILED(res)) { Net_Shutdown(session); return -1; }

    res = udsCreateNetwork(&session->network, appData, sizeof(appData),
                            s_udsBuffer, UDS_BUFFER_SIZE);
    if (R_FAILED(res)) { Net_Shutdown(session); return -1; }

    session->isHost = 1;
    session->initialized = 1;
    printf("Hosting local game: %s\n", sessionName ? sessionName : "voxelgame");
    return 0;
}

int Net_Join(NetSession* session) {
    memset(session, 0, sizeof(NetSession));

    Result res = udsInit(NULL, NULL);
    if (R_FAILED(res)) return -1;

    s_udsBuffer = (u8*)malloc(UDS_BUFFER_SIZE);
    if (!s_udsBuffer) { udsExit(); return -1; }

    udsNetworkScanInfo scanResults[8];
    size_t actualCount = 0;
    res = udsScanBeacons(scanResults, 8, &actualCount, NULL, 0, 0x4D43, 0, false);
    if (R_FAILED(res) || actualCount == 0) {
        printf("No local games found to join.\n");
        Net_Shutdown(session);
        return -1;
    }

    session->network = scanResults[0].network;
    res = udsConnectNetwork(&session->network, NULL, 0,
                             s_udsBuffer, UDS_BUFFER_SIZE,
                             UDS_BROADCAST_NETWORKNODEID, UDS_CONNECTION_TYPE_CLIENT);
    if (R_FAILED(res)) { Net_Shutdown(session); return -1; }

    session->isHost = 0;
    session->initialized = 1;
    printf("Joined local game.\n");
    return 0;
}

void Net_SendState(NetSession* session, const NetPlayerState* localState) {
    if (!session->initialized) return;

    NetPacket pkt;
    pkt.slot = session->isHost ? 0 : 1; /* TODO: real slot assignment for >2 players */
    pkt.x = localState->x;
    pkt.y = localState->y;
    pkt.z = localState->z;
    pkt.yaw = localState->yaw;

    /* Broadcast to all connected peers on our channel. */
    udsSendTo(UDS_BROADCAST_NETWORKNODEID, NET_CHANNEL, UDS_SENDFLAG_Default,
              &pkt, sizeof(pkt));
}

int Net_Poll(NetSession* session) {
    if (!session->initialized) return 0;

    int updated = 0;
    u8 recvBuf[256];
    size_t actualSize = 0;
    u16 srcNetworkNodeId = 0;

    /* Drain whatever packets arrived since last frame. */
    while (1) {
        Result res = udsPullPacket(s_udsBuffer, sizeof(recvBuf), &actualSize,
                                    &srcNetworkNodeId, recvBuf);
        if (R_FAILED(res) || actualSize == 0) break;
        if (actualSize < sizeof(NetPacket)) continue;

        NetPacket* pkt = (NetPacket*)recvBuf;
        if (pkt->slot < NET_MAX_PEERS) {
            session->peers[pkt->slot].x = pkt->x;
            session->peers[pkt->slot].y = pkt->y;
            session->peers[pkt->slot].z = pkt->z;
            session->peers[pkt->slot].yaw = pkt->yaw;
            updated++;
        }
    }
    return updated;
}

void Net_Shutdown(NetSession* session) {
    if (session->initialized) {
        udsDestroyNetwork();
        udsUnbind();
    }
    if (s_udsBuffer) { free(s_udsBuffer); s_udsBuffer = NULL; }
    udsExit();
    memset(session, 0, sizeof(NetSession));
}
