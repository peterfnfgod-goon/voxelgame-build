#pragma once
#include "world.h"

#define INVENTORY_SLOTS 8

typedef enum {
    ITEM_NONE = 0,
    ITEM_GRASS_BLOCK,
    ITEM_DIRT_BLOCK,
    ITEM_STONE_BLOCK,
    ITEM_WOOD_BLOCK,
    ITEM_LEAVES_BLOCK,
    ITEM_SAND_BLOCK,
    ITEM_PLANK_BLOCK,
    ITEM_GLASS_BLOCK,
    ITEM_COAL_ORE_BLOCK,
    ITEM_IRON_ORE_BLOCK,
    ITEM_SNOW_BLOCK,
    ITEM_STICK,
    ITEM_PLANK,
    ITEM_COAL,
    ITEM_IRON_INGOT,
    ITEM_PICKAXE,
    ITEM_AXE,
    ITEM_SWORD,
    ITEM_COUNT
} ItemType;

typedef struct {
    ItemType item;
    int count;
} InventorySlot;

typedef struct {
    InventorySlot slots[INVENTORY_SLOTS];
    int selected;
} Inventory;

typedef struct {
    ItemType inputs[3];   /* up to 3 distinct ingredient types required */
    int inputCounts[3];
    ItemType output;
    int outputCount;
    const char* name;
} Recipe;

void Inventory_Init(Inventory* inv);
int  Inventory_Add(Inventory* inv, ItemType item, int count);
int  Inventory_Remove(Inventory* inv, ItemType item, int count);
int  Inventory_Count(Inventory* inv, ItemType item);

/* Block broken -> item gained */
ItemType Block_ToItem(BlockType block);
/* Item placed -> block type (ITEM_NONE-safe; returns BLOCK_AIR if not placeable) */
BlockType Item_ToBlock(ItemType item);

/* Attempts to craft using the given recipe; returns 1 on success */
int Craft(Inventory* inv, const Recipe* recipe);

/* A small fixed set of starter recipes, original to this game */
extern const Recipe RECIPES[];
extern const int RECIPE_COUNT;
