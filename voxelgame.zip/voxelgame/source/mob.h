#pragma once
#include "world.h"

#define MAX_MOBS 24

typedef enum {
    MOB_NONE = 0,
    MOB_ANIMAL,    /* passive, wanders around, can be a food source */
    MOB_SHAMBLER,  /* slow hostile mob that chases the player and deals contact damage */
    MOB_FLYER,     /* erratic flying hostile, swoops at the player */
    MOB_BRUTE      /* tougher, slower hostile with higher damage and more health */
} MobType;

typedef enum {
    AI_IDLE,
    AI_WANDER,
    AI_CHASE,
    AI_ATTACK
} AiState;

typedef struct {
    MobType type;
    int alive;
    float x, y, z;
    float vx, vy, vz;
    float health;
    float wanderTimer;
    float attackCooldown;
    AiState state;
} Mob;

typedef struct {
    Mob mobs[MAX_MOBS];
    int count;
} MobManager;

void Mob_InitManager(MobManager* mgr);
int  Mob_Spawn(MobManager* mgr, MobType type, float x, float y, float z);
void Mob_Update(MobManager* mgr, Chunk* chunk, float playerX, float playerY, float playerZ,
                float dt, int isNight, float* outDamageToPlayer);
void Mob_GetColor(MobType type, float* r, float* g, float* b);
