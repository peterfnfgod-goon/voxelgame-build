#include "world.h"
#include <3ds.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void World_Init(Chunk* chunk) {
    memset(chunk->blocks, BLOCK_AIR, sizeof(chunk->blocks));
}

/* 2D value noise - returns [0,1). Used for terrain height and biome selection. */
static float noise2d(int x, int z, unsigned int seed) {
    unsigned int n = (x * 374761393u + z * 668265263u + seed * 2147483647u);
    n = (n ^ (n >> 13)) * 1274126177u;
    n = n ^ (n >> 16);
    return (n % 1000) / 1000.0f;
}

/* 3D value noise - returns [0,1). Used for cave carving and 3D ore deposits. */
static float noise3d(int x, int y, int z, unsigned int seed) {
    unsigned int n = (x * 374761393u + y * 1234567891u + z * 668265263u + seed * 2147483647u);
    n = (n ^ (n >> 13)) * 1274126177u;
    n = n ^ (n >> 16);
    return (n % 1000) / 1000.0f;
}

/* Layered 2D noise: sample at 3 scales and blend for smoother hills.
 * base scale gives broad rises, mid scale adds secondary hills,
 * fine scale adds bumps. Returns a [0,1) height factor. */
static float terrainHeight(int x, int z, unsigned int seed) {
    float h  = noise2d(x,     z,     seed)      * 0.50f; /* broad hills */
    float h2 = noise2d(x * 2, z * 2, seed + 11) * 0.30f; /* secondary rolls */
    float h3 = noise2d(x * 4, z * 4, seed + 22) * 0.20f; /* surface bumps */
    return h + h2 + h3;                                    /* sums to [0,1) */
}

/* Cave carving: a block is carved out when two independent 3D noise values
 * both exceed a threshold. Using the product of two noises creates veins
 * (tunnels, caverns) rather than uniform swiss-cheese. Separate seeds
 * keep the two fields decorrelated so the shapes are varied. */
static int isCave(int x, int y, int z, unsigned int seed) {
    /* Don't carve very top layers - keeps the surface solid */
    if (y >= CHUNK_SIZE_Y - 4) return 0;
    float a = noise3d(x, y,     z,     seed + 777);
    float b = noise3d(x, y + 5, z + 7, seed + 888); /* offset so peaks don't overlap */
    /* Higher threshold = fewer, tighter tunnels. 0.72 gives generous caves
     * without making the surface look like a sieve. */
    return (a > 0.72f && b > 0.72f);
}

void World_Generate(Chunk* chunk, unsigned int seed) {
    World_Init(chunk);

    /* Terrain heights span y=6 to y=CHUNK_SIZE_Y-5 giving ~13 blocks of
     * headroom for hills while keeping a thick underground to explore. */
    const int minH  = 6;
    const int rangeH = CHUNK_SIZE_Y - 9 - minH; /* ~9 */
    const int waterLevel = minH;

    /* --- Pass 1: lay down solid terrain ---------------------------------- */
    for (int x = 0; x < CHUNK_SIZE_X; x++) {
        for (int z = 0; z < CHUNK_SIZE_Z; z++) {
            float hf      = terrainHeight(x, z, seed);
            float biomeN  = noise2d(x + 300, z + 300, seed + 5);
            float desertN = noise2d(x + 600, z + 600, seed + 6);
            int height    = minH + (int)(hf * rangeH);
            int isSnow    = (biomeN > 0.75f);
            int isDesert  = (desertN > 0.80f && !isSnow);

            for (int y = 0; y < CHUNK_SIZE_Y; y++) {
                BlockType t = BLOCK_AIR;

                if (y < height - 1) {
                    /* Underground: stone by default, ores by depth+rarity */
                    t = BLOCK_STONE;
                    float oreN = noise3d(x, y, z, seed + 99);

                    /* Coal: common, any underground depth */
                    if (oreN > 0.88f)
                        t = BLOCK_COAL_ORE;
                    /* Iron: less common, below y=height-3 */
                    else if (y < height - 3 && oreN > 0.94f)
                        t = BLOCK_IRON_ORE;
                    /* Gold: rare, below y=5 (only accessible in deeper terrain) */
                    else if (y < 5 && oreN > 0.960f)
                        t = BLOCK_GOLD_ORE;
                    /* Diamond: very rare, y<=2 only - deep mining reward */
                    else if (y <= 2 && oreN > 0.975f)
                        t = BLOCK_DIAMOND_ORE;

                } else if (y < height) {
                    t = isDesert ? BLOCK_SAND : BLOCK_DIRT;

                } else if (y == height) {
                    /* Surface block depends on biome */
                    if (height <= waterLevel)      t = BLOCK_SAND;
                    else if (isSnow)               t = BLOCK_SNOW;
                    else if (isDesert)             t = BLOCK_SAND;
                    else                           t = BLOCK_GRASS;

                } else if (y <= waterLevel && height <= waterLevel) {
                    t = BLOCK_WATER;
                }

                chunk->blocks[x][y][z] = t;
            }

            /* Trees: not in desert/snow, not underwater, surface not too flat
             * (height > waterLevel+1) and enough vertical room for a full tree */
            if (!isSnow && !isDesert && height > waterLevel + 1) {
                float treeN = noise2d(x * 7 + 3, z * 7 + 3, seed + 42);
                if (treeN > 0.87f && height + 7 < CHUNK_SIZE_Y) {
                    int trunkHeight = 4 + (int)((treeN - 0.87f) / 0.13f * 2.0f); /* 4 or 5 blocks */
                    int trunkTop = height + trunkHeight;

                    for (int ty = height + 1; ty <= trunkTop; ty++)
                        chunk->blocks[x][ty][z] = BLOCK_WOOD;

                    /* Leaf blob: 2 layers of 3x3, 1 layer of 1x1 cap */
                    for (int ly = trunkTop - 1; ly <= trunkTop + 1; ly++) {
                        int radius = (ly <= trunkTop) ? 1 : 0;
                        for (int lx = x - radius; lx <= x + radius; lx++) {
                            for (int lz = z - radius; lz <= z + radius; lz++) {
                                if (lx < 0 || lx >= CHUNK_SIZE_X) continue;
                                if (lz < 0 || lz >= CHUNK_SIZE_Z) continue;
                                if (ly < 0 || ly >= CHUNK_SIZE_Y) continue;
                                if (chunk->blocks[lx][ly][lz] == BLOCK_AIR)
                                    chunk->blocks[lx][ly][lz] = BLOCK_LEAVES;
                            }
                        }
                    }
                    /* Separate wider leaf layer at trunkTop-1 */
                    for (int lx = x - 2; lx <= x + 2; lx++) {
                        for (int lz = z - 2; lz <= z + 2; lz++) {
                            if (lx < 0 || lx >= CHUNK_SIZE_X) continue;
                            if (lz < 0 || lz >= CHUNK_SIZE_Z) continue;
                            /* Skip corners for a rounder shape */
                            if (abs(lx - x) == 2 && abs(lz - z) == 2) continue;
                            int ly = trunkTop - 1;
                            if (chunk->blocks[lx][ly][lz] == BLOCK_AIR)
                                chunk->blocks[lx][ly][lz] = BLOCK_LEAVES;
                        }
                    }
                }
            }
        }
    }

    /* --- Pass 2: carve caves --------------------------------------------- */
    /* Done after terrain so caves can intersect any block type (including
     * ores - finding an ore vein by following a cave is a core gameplay
     * moment, so we want cave walls to expose ore faces). We don't carve
     * the topmost surface layer so the world doesn't look like a crater. */
    for (int x = 0; x < CHUNK_SIZE_X; x++) {
        for (int y = 1; y < CHUNK_SIZE_Y - 4; y++) {
            for (int z = 0; z < CHUNK_SIZE_Z; z++) {
                if (chunk->blocks[x][y][z] == BLOCK_AIR  ||
                    chunk->blocks[x][y][z] == BLOCK_WATER) continue;
                if (isCave(x, y, z, seed))
                    chunk->blocks[x][y][z] = BLOCK_AIR;
            }
        }
    }
}

BlockType World_GetBlock(Chunk* chunk, int x, int y, int z) {
    if (x < 0 || x >= CHUNK_SIZE_X || y < 0 || y >= CHUNK_SIZE_Y || z < 0 || z >= CHUNK_SIZE_Z)
        return BLOCK_AIR;
    return chunk->blocks[x][y][z];
}

void World_SetBlock(Chunk* chunk, int x, int y, int z, BlockType type) {
    if (x < 0 || x >= CHUNK_SIZE_X || y < 0 || y >= CHUNK_SIZE_Y || z < 0 || z >= CHUNK_SIZE_Z)
        return;
    chunk->blocks[x][y][z] = type;
}

int World_IsSolid(Chunk* chunk, int x, int y, int z) {
    return World_GetBlock(chunk, x, y, z) != BLOCK_AIR;
}

int World_IsSolidForPhysics(Chunk* chunk, int x, int y, int z) {
    BlockType t = World_GetBlock(chunk, x, y, z);
    return t != BLOCK_AIR && t != BLOCK_WATER;
}

void Block_GetColor(BlockType type, float* r, float* g, float* b) {
    switch (type) {
        case BLOCK_GRASS:       *r=0.30f; *g=0.65f; *b=0.25f; break;
        case BLOCK_DIRT:        *r=0.45f; *g=0.30f; *b=0.18f; break;
        case BLOCK_STONE:       *r=0.55f; *g=0.55f; *b=0.55f; break;
        case BLOCK_WOOD:        *r=0.40f; *g=0.26f; *b=0.13f; break;
        case BLOCK_LEAVES:      *r=0.18f; *g=0.45f; *b=0.16f; break;
        case BLOCK_SAND:        *r=0.86f; *g=0.80f; *b=0.55f; break;
        case BLOCK_PLANK:       *r=0.65f; *g=0.48f; *b=0.27f; break;
        case BLOCK_GLASS:       *r=0.75f; *g=0.88f; *b=0.90f; break;
        case BLOCK_WATER:       *r=0.20f; *g=0.40f; *b=0.85f; break;
        case BLOCK_COAL_ORE:    *r=0.30f; *g=0.30f; *b=0.32f; break;
        case BLOCK_IRON_ORE:    *r=0.70f; *g=0.60f; *b=0.50f; break;
        case BLOCK_GOLD_ORE:    *r=0.85f; *g=0.70f; *b=0.10f; break; /* yellow-gold fleck in stone */
        case BLOCK_DIAMOND_ORE: *r=0.30f; *g=0.80f; *b=0.90f; break; /* bright cyan-blue glint */
        case BLOCK_SNOW:        *r=0.92f; *g=0.94f; *b=0.97f; break;
        default:                *r=1.0f;  *g=0.0f;  *b=1.0f;  break;
    }
}

int Block_IsTransparent(BlockType type) {
    return type == BLOCK_AIR || type == BLOCK_GLASS || type == BLOCK_WATER;
}

/* Cheap directional shading so cubes don't look flat: top faces brightest,
 * bottom darkest, side faces in between. This is the standard "fake AO"
 * trick lots of small voxel engines use instead of real lighting. */
static float faceBrightness(int face) {
    switch (face) {
        case 2: return 1.00f; /* +Y top */
        case 3: return 0.55f; /* -Y bottom */
        case 0: case 1: return 0.80f; /* +X/-X sides */
        default: return 0.70f; /* +Z/-Z sides */
    }
}

/* Adds one quad (two triangles) for a cube face */
static int addFace(VoxelVertex* v, int idx, float x, float y, float z, int face, float r, float g, float b) {
    float shade = faceBrightness(face);
    r *= shade; g *= shade; b *= shade;
    float corners[6][4][3] = {
        /* +X */ {{x+1,y,z},{x+1,y+1,z},{x+1,y+1,z+1},{x+1,y,z+1}},
        /* -X */ {{x,y,z+1},{x,y+1,z+1},{x,y+1,z},{x,y,z}},
        /* +Y */ {{x,y+1,z},{x,y+1,z+1},{x+1,y+1,z+1},{x+1,y+1,z}},
        /* -Y */ {{x,y,z+1},{x,y,z},{x+1,y,z},{x+1,y,z+1}},
        /* +Z */ {{x+1,y,z+1},{x+1,y+1,z+1},{x,y+1,z+1},{x,y,z+1}},
        /* -Z */ {{x,y,z},{x,y+1,z},{x+1,y+1,z},{x+1,y,z}},
    };
    int order[6] = {0,1,2, 0,2,3};
    for (int i = 0; i < 6; i++) {
        float* c = corners[face][order[i]];
        v[idx].x = c[0]; v[idx].y = c[1]; v[idx].z = c[2];
        v[idx].r = r; v[idx].g = g; v[idx].b = b;
        idx++;
    }
    return idx;
}

int World_BuildMesh(Chunk* chunk, VoxelVertex** outVerts) {
    /* Worst case (every block fully exposed) would be ~47MB for 48x48x24.
     * Cap at a safe 20MB budget; with cave carving + occlusion culling the
     * real count is typically well under 10MB. If we somehow hit the cap the
     * world just goes unrendered beyond that point - not ideal but safe. */
    int maxVerts = (20 * 1024 * 1024) / (int)sizeof(VoxelVertex);
    VoxelVertex* verts = (VoxelVertex*)linearAlloc(sizeof(VoxelVertex) * maxVerts);
    if (!verts) { *outVerts = NULL; return 0; }
    int idx = 0;

    for (int x = 0; x < CHUNK_SIZE_X; x++) {
        for (int y = 0; y < CHUNK_SIZE_Y; y++) {
            for (int z = 0; z < CHUNK_SIZE_Z; z++) {
                BlockType t = chunk->blocks[x][y][z];
                if (t == BLOCK_AIR) continue;
                float r, g, b;
                Block_GetColor(t, &r, &g, &b);

                if (idx + 36 >= maxVerts) goto done; /* safety cap */

                if (!World_IsSolid(chunk, x+1, y, z)) idx = addFace(verts, idx, x, y, z, 0, r, g, b);
                if (!World_IsSolid(chunk, x-1, y, z)) idx = addFace(verts, idx, x, y, z, 1, r, g, b);
                if (!World_IsSolid(chunk, x, y+1, z)) idx = addFace(verts, idx, x, y, z, 2, r, g, b);
                if (!World_IsSolid(chunk, x, y-1, z)) idx = addFace(verts, idx, x, y, z, 3, r, g, b);
                if (!World_IsSolid(chunk, x, y, z+1)) idx = addFace(verts, idx, x, y, z, 4, r, g, b);
                if (!World_IsSolid(chunk, x, y, z-1)) idx = addFace(verts, idx, x, y, z, 5, r, g, b);
            }
        }
    }
done:
    *outVerts = verts;
    return idx;
}

void World_FreeMesh(VoxelVertex* verts) {
    linearFree(verts);
}
