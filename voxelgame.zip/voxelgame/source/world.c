#include "world.h"
#include <3ds.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void World_Init(Chunk* chunk) {
    memset(chunk->blocks, BLOCK_AIR, sizeof(chunk->blocks));
}

/* Very small deterministic pseudo-noise so terrain looks varied without
 * needing a real Perlin noise implementation. Good enough for a first pass. */
static float simpleNoise(int x, int z, unsigned int seed) {
    unsigned int n = (x * 374761393u + z * 668265263u + seed * 2147483647u);
    n = (n ^ (n >> 13)) * 1274126177u;
    n = n ^ (n >> 16);
    return (n % 1000) / 1000.0f;
}

void World_Generate(Chunk* chunk, unsigned int seed) {
    World_Init(chunk);
    int waterLevel = 3;
    for (int x = 0; x < CHUNK_SIZE_X; x++) {
        for (int z = 0; z < CHUNK_SIZE_Z; z++) {
            float n = simpleNoise(x, z, seed);
            float biomeN = simpleNoise(x + 500, z + 500, seed);
            int height = 4 + (int)(n * 5.0f); /* terrain height 4-8 */
            int isSnowBiome = biomeN > 0.8f;

            for (int y = 0; y < CHUNK_SIZE_Y; y++) {
                if (y < height - 1) {
                    BlockType rock = BLOCK_STONE;
                    /* sprinkle in some ore deposits underground */
                    float oreN = simpleNoise(x * 3 + y, z * 7 + y, seed + 99);
                    if (y < height - 2 && oreN > 0.93f) rock = BLOCK_COAL_ORE;
                    else if (y < height - 3 && oreN > 0.965f) rock = BLOCK_IRON_ORE;
                    chunk->blocks[x][y][z] = rock;
                } else if (y < height) {
                    chunk->blocks[x][y][z] = BLOCK_DIRT;
                } else if (y == height) {
                    if (height <= waterLevel) chunk->blocks[x][y][z] = BLOCK_SAND;
                    else chunk->blocks[x][y][z] = isSnowBiome ? BLOCK_SNOW : BLOCK_GRASS;
                } else if (y <= waterLevel && height <= waterLevel) {
                    chunk->blocks[x][y][z] = BLOCK_WATER; /* fill low areas into little lakes */
                } else {
                    chunk->blocks[x][y][z] = BLOCK_AIR;
                }
            }
            /* occasional tree (not in snow biome, not underwater) */
            if (!isSnowBiome && height > waterLevel && n > 0.92f && height + 4 < CHUNK_SIZE_Y) {
                int trunkTop = height + 3;
                for (int ty = height + 1; ty <= trunkTop; ty++) {
                    chunk->blocks[x][ty][z] = BLOCK_WOOD;
                }
                if (trunkTop + 1 < CHUNK_SIZE_Y) {
                    chunk->blocks[x][trunkTop + 1][z] = BLOCK_LEAVES;
                }
            }
        }
    }
}

BlockType World_GetBlock(Chunk* chunk, int x, int y, int z) {
    if (x < 0 || x >= CHUNK_SIZE_X || y < 0 || y >= CHUNK_SIZE_Y || z < 0 || z >= CHUNK_SIZE_Z)
        return BLOCK_AIR;
    return chunk->blocks[x][y][z];
}

void World_SetBlock(Chunk* chunk, int x, int y, int z, BlockType type) {
    if (x < 0 || x >= CHUNK_SIZE_X || y < 0 || y >= CHUNK_SIZE_Y || z < 0 || z >= CHUNK_SIZE_Z)
        return;
    chunk->blocks[x][y][z] = type;
}

int World_IsSolid(Chunk* chunk, int x, int y, int z) {
    return World_GetBlock(chunk, x, y, z) != BLOCK_AIR;
}

void Block_GetColor(BlockType type, float* r, float* g, float* b) {
    switch (type) {
        case BLOCK_GRASS:    *r=0.30f; *g=0.65f; *b=0.25f; break;
        case BLOCK_DIRT:     *r=0.45f; *g=0.30f; *b=0.18f; break;
        case BLOCK_STONE:    *r=0.55f; *g=0.55f; *b=0.55f; break;
        case BLOCK_WOOD:     *r=0.40f; *g=0.26f; *b=0.13f; break;
        case BLOCK_LEAVES:   *r=0.18f; *g=0.45f; *b=0.16f; break;
        case BLOCK_SAND:     *r=0.86f; *g=0.80f; *b=0.55f; break;
        case BLOCK_PLANK:    *r=0.65f; *g=0.48f; *b=0.27f; break;
        case BLOCK_GLASS:    *r=0.75f; *g=0.88f; *b=0.90f; break;
        case BLOCK_WATER:    *r=0.20f; *g=0.40f; *b=0.85f; break;
        case BLOCK_COAL_ORE: *r=0.30f; *g=0.30f; *b=0.32f; break;
        case BLOCK_IRON_ORE: *r=0.70f; *g=0.60f; *b=0.50f; break;
        case BLOCK_SNOW:     *r=0.92f; *g=0.94f; *b=0.97f; break;
        default:              *r=1.0f;  *g=0.0f;  *b=1.0f;  break; /* shouldn't render */
    }
}

int Block_IsTransparent(BlockType type) {
    return type == BLOCK_AIR || type == BLOCK_GLASS || type == BLOCK_WATER;
}

/* Cheap directional shading so cubes don't look flat: top faces brightest,
 * bottom darkest, side faces in between. This is the standard "fake AO"
 * trick lots of small voxel engines use instead of real lighting. */
static float faceBrightness(int face) {
    switch (face) {
        case 2: return 1.00f; /* +Y top */
        case 3: return 0.55f; /* -Y bottom */
        case 0: case 1: return 0.80f; /* +X/-X sides */
        default: return 0.70f; /* +Z/-Z sides */
    }
}

/* Adds one quad (two triangles) for a cube face */
static int addFace(VoxelVertex* v, int idx, float x, float y, float z, int face, float r, float g, float b) {
    float shade = faceBrightness(face);
    r *= shade; g *= shade; b *= shade;
    /* Define the 4 corners per face explicitly for clarity */
    float corners[6][4][3] = {
        /* +X */ {{x+1,y,z},{x+1,y+1,z},{x+1,y+1,z+1},{x+1,y,z+1}},
        /* -X */ {{x,y,z+1},{x,y+1,z+1},{x,y+1,z},{x,y,z}},
        /* +Y */ {{x,y+1,z},{x,y+1,z+1},{x+1,y+1,z+1},{x+1,y+1,z}},
        /* -Y */ {{x,y,z+1},{x,y,z},{x+1,y,z},{x+1,y,z+1}},
        /* +Z */ {{x+1,y,z+1},{x+1,y+1,z+1},{x,y+1,z+1},{x,y,z+1}},
        /* -Z */ {{x,y,z},{x,y+1,z},{x+1,y+1,z},{x+1,y,z}},
    };
    /* two triangles: 0,1,2 and 0,2,3 */
    int order[6] = {0,1,2, 0,2,3};
    for (int i = 0; i < 6; i++) {
        float* c = corners[face][order[i]];
        v[idx].x = c[0]; v[idx].y = c[1]; v[idx].z = c[2];
        v[idx].r = r; v[idx].g = g; v[idx].b = b;
        idx++;
    }
    return idx;
}

int World_BuildMesh(Chunk* chunk, VoxelVertex** outVerts) {
    /* worst case: every block has 6 visible faces * 6 verts */
    int maxVerts = CHUNK_SIZE_X * CHUNK_SIZE_Y * CHUNK_SIZE_Z * 6 * 6;
    /* Must be linearAlloc'd (not malloc'd): citro3d hands the GPU this
     * buffer's *physical* address directly (see C3D_BufInfo in main.c), and
     * only the linear heap is guaranteed to be physically contiguous and
     * mappable that way. Plain malloc'd memory is not safe to feed the GPU
     * here. Caller must free with World_FreeMesh(), not free(). */
    VoxelVertex* verts = (VoxelVertex*)linearAlloc(sizeof(VoxelVertex) * maxVerts);
    int idx = 0;

    for (int x = 0; x < CHUNK_SIZE_X; x++) {
        for (int y = 0; y < CHUNK_SIZE_Y; y++) {
            for (int z = 0; z < CHUNK_SIZE_Z; z++) {
                BlockType t = chunk->blocks[x][y][z];
                if (t == BLOCK_AIR) continue;
                float r, g, b;
                Block_GetColor(t, &r, &g, &b);

                if (!World_IsSolid(chunk, x+1, y, z)) idx = addFace(verts, idx, x, y, z, 0, r, g, b);
                if (!World_IsSolid(chunk, x-1, y, z)) idx = addFace(verts, idx, x, y, z, 1, r, g, b);
                if (!World_IsSolid(chunk, x, y+1, z)) idx = addFace(verts, idx, x, y, z, 2, r, g, b);
                if (!World_IsSolid(chunk, x, y-1, z)) idx = addFace(verts, idx, x, y, z, 3, r, g, b);
                if (!World_IsSolid(chunk, x, y, z+1)) idx = addFace(verts, idx, x, y, z, 4, r, g, b);
                if (!World_IsSolid(chunk, x, y, z-1)) idx = addFace(verts, idx, x, y, z, 5, r, g, b);
            }
        }
    }

    *outVerts = verts;
    return idx;
}

void World_FreeMesh(VoxelVertex* verts) {
    linearFree(verts);
}
