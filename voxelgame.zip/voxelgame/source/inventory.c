#include "inventory.h"
#include <string.h>

void Inventory_Init(Inventory* inv) {
    memset(inv, 0, sizeof(Inventory));
    inv->selected = 0;
}

int Inventory_Add(Inventory* inv, ItemType item, int count) {
    if (item == ITEM_NONE || count <= 0) return 0;
    /* stack onto existing slot first */
    for (int i = 0; i < INVENTORY_SLOTS; i++) {
        if (inv->slots[i].item == item) {
            inv->slots[i].count += count;
            return 1;
        }
    }
    /* otherwise find empty slot */
    for (int i = 0; i < INVENTORY_SLOTS; i++) {
        if (inv->slots[i].item == ITEM_NONE) {
            inv->slots[i].item = item;
            inv->slots[i].count = count;
            return 1;
        }
    }
    return 0; /* inventory full */
}

int Inventory_Count(Inventory* inv, ItemType item) {
    for (int i = 0; i < INVENTORY_SLOTS; i++) {
        if (inv->slots[i].item == item) return inv->slots[i].count;
    }
    return 0;
}

int Inventory_Remove(Inventory* inv, ItemType item, int count) {
    for (int i = 0; i < INVENTORY_SLOTS; i++) {
        if (inv->slots[i].item == item) {
            if (inv->slots[i].count < count) return 0;
            inv->slots[i].count -= count;
            if (inv->slots[i].count == 0) inv->slots[i].item = ITEM_NONE;
            return 1;
        }
    }
    return 0;
}

ItemType Block_ToItem(BlockType block) {
    switch (block) {
        case BLOCK_GRASS:    return ITEM_GRASS_BLOCK;
        case BLOCK_DIRT:     return ITEM_DIRT_BLOCK;
        case BLOCK_STONE:    return ITEM_STONE_BLOCK;
        case BLOCK_WOOD:     return ITEM_WOOD_BLOCK;
        case BLOCK_LEAVES:   return ITEM_LEAVES_BLOCK;
        case BLOCK_SAND:     return ITEM_SAND_BLOCK;
        case BLOCK_PLANK:    return ITEM_PLANK_BLOCK;
        case BLOCK_GLASS:    return ITEM_GLASS_BLOCK;
        case BLOCK_COAL_ORE: return ITEM_COAL_ORE_BLOCK;
        case BLOCK_IRON_ORE: return ITEM_IRON_ORE_BLOCK;
        case BLOCK_SNOW:     return ITEM_SNOW_BLOCK;
        default: return ITEM_NONE; /* water etc. isn't collectible as a block item */
    }
}

BlockType Item_ToBlock(ItemType item) {
    switch (item) {
        case ITEM_GRASS_BLOCK:    return BLOCK_GRASS;
        case ITEM_DIRT_BLOCK:     return BLOCK_DIRT;
        case ITEM_STONE_BLOCK:    return BLOCK_STONE;
        case ITEM_WOOD_BLOCK:     return BLOCK_WOOD;
        case ITEM_LEAVES_BLOCK:   return BLOCK_LEAVES;
        case ITEM_SAND_BLOCK:     return BLOCK_SAND;
        case ITEM_PLANK_BLOCK:    return BLOCK_PLANK;
        case ITEM_GLASS_BLOCK:    return BLOCK_GLASS;
        case ITEM_COAL_ORE_BLOCK: return BLOCK_COAL_ORE;
        case ITEM_IRON_ORE_BLOCK: return BLOCK_IRON_ORE;
        case ITEM_SNOW_BLOCK:     return BLOCK_SNOW;
        case ITEM_PLANK:          return BLOCK_PLANK; /* loose planks place as plank block too */
        default: return BLOCK_AIR;
    }
}

/* Original, simple recipe set - not derived from any specific existing game */
const Recipe RECIPES[] = {
    { {ITEM_WOOD_BLOCK, ITEM_NONE, ITEM_NONE},     {1,0,0}, ITEM_PLANK, 4,        "Wood Block -> 4 Planks" },
    { {ITEM_PLANK, ITEM_NONE, ITEM_NONE},          {2,0,0}, ITEM_STICK, 4,        "2 Planks -> 4 Sticks" },
    { {ITEM_COAL_ORE_BLOCK, ITEM_NONE, ITEM_NONE}, {1,0,0}, ITEM_COAL, 2,         "Coal Ore -> 2 Coal" },
    { {ITEM_IRON_ORE_BLOCK, ITEM_COAL, ITEM_NONE}, {1,1,0}, ITEM_IRON_INGOT, 1,   "Iron Ore + Coal -> Iron Ingot" },
    { {ITEM_PLANK, ITEM_STICK, ITEM_NONE},         {3,2,0}, ITEM_PICKAXE, 1,      "3 Planks + 2 Sticks -> Pickaxe" },
    { {ITEM_PLANK, ITEM_STICK, ITEM_NONE},         {3,2,0}, ITEM_AXE, 1,          "3 Planks + 2 Sticks -> Axe" },
    { {ITEM_IRON_INGOT, ITEM_STICK, ITEM_NONE},    {2,1,0}, ITEM_SWORD, 1,        "2 Iron Ingots + Stick -> Sword" },
};
const int RECIPE_COUNT = sizeof(RECIPES) / sizeof(Recipe);

int Craft(Inventory* inv, const Recipe* recipe) {
    /* check all required ingredients first */
    for (int i = 0; i < 3; i++) {
        if (recipe->inputs[i] == ITEM_NONE) continue;
        if (Inventory_Count(inv, recipe->inputs[i]) < recipe->inputCounts[i]) {
            return 0;
        }
    }
    /* consume */
    for (int i = 0; i < 3; i++) {
        if (recipe->inputs[i] == ITEM_NONE) continue;
        Inventory_Remove(inv, recipe->inputs[i], recipe->inputCounts[i]);
    }
    Inventory_Add(inv, recipe->output, recipe->outputCount);
    return 1;
}
