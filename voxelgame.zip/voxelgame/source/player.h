#pragma once
#include "world.h"

/* Player capsule approximated as an axis-aligned box for collision: a
 * radius around (x,z) and a height from y up to y+PLAYER_HEIGHT. Simple,
 * not a "real" capsule, but enough to stop walking through walls. */
#define PLAYER_RADIUS      0.3f
#define PLAYER_HEIGHT      1.7f
#define PLAYER_EYE_HEIGHT  1.5f /* camera offset above p->y, used by main.c too */

#define PLAYER_GRAVITY      20.0f  /* units/s^2 */
#define PLAYER_JUMP_SPEED    7.0f  /* initial upward velocity on jump */
#define PLAYER_TERMINAL_VY -30.0f  /* fall speed cap so things don't get silly */

typedef struct {
    float x, y, z;
    float yaw;   /* facing angle, radians */
    float pitch;
    float health;
    float hunger;
    float vy;       /* vertical velocity, for gravity/jumping */
    int   onGround;  /* set by Player_UpdatePhysics each frame */
} Player;

void Player_Init(Player* p, float x, float y, float z);

/* Horizontal movement, collided against the world a step at a time so the
 * player slides along walls instead of stopping dead or clipping through. */
void Player_Move(Player* p, Chunk* world, float forward, float strafe, float dt);

void Player_Look(Player* p, float dYaw, float dPitch);

/* Gravity + jump + vertical collision. Call once per frame; jumpPressed
 * should be true only on the frame the jump button was pressed (a "Down"
 * edge, not "Held"), so holding the button doesn't bunny-hop endlessly. */
void Player_UpdatePhysics(Player* p, Chunk* world, float dt, int jumpPressed);
