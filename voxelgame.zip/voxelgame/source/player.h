#pragma once

typedef struct {
    float x, y, z;
    float yaw;   /* facing angle, radians */
    float pitch;
    float health;
    float hunger;
} Player;

void Player_Init(Player* p, float x, float y, float z);
void Player_Move(Player* p, float forward, float strafe, float dt);
void Player_Look(Player* p, float dYaw, float dPitch);
