#pragma once
#include <citro3d.h>

/* Map is 48x48 blocks wide and 24 blocks tall - 3x the original footprint.
 * Worst-case mesh is 48*24*48*6*6 verts (~25M bytes in linear mem), but
 * real geometry stays well under that once caves hollow out the interior
 * and opaque faces are hidden inside solid rock. */
#define CHUNK_SIZE_X 48
#define CHUNK_SIZE_Y 24
#define CHUNK_SIZE_Z 48

typedef enum {
    BLOCK_AIR = 0,
    BLOCK_GRASS,
    BLOCK_DIRT,
    BLOCK_STONE,
    BLOCK_WOOD,      /* log */
    BLOCK_LEAVES,
    BLOCK_SAND,
    BLOCK_PLANK,
    BLOCK_GLASS,
    BLOCK_WATER,
    BLOCK_COAL_ORE,
    BLOCK_IRON_ORE,
    BLOCK_GOLD_ORE,     /* mid-depth, rarer than iron */
    BLOCK_DIAMOND_ORE,  /* deep-only, rarest */
    BLOCK_SNOW,
    BLOCK_COUNT
} BlockType;

/* Is this block see-through / non-solid for rendering & physics purposes?
 * (water and glass still render, but shouldn't fully block light/AO the way
 * stone does - kept simple here, used by World_IsSolid callers as needed) */
int Block_IsTransparent(BlockType type);

typedef struct {
    BlockType blocks[CHUNK_SIZE_X][CHUNK_SIZE_Y][CHUNK_SIZE_Z];
} Chunk;

typedef struct {
    float x, y, z;
    float r, g, b;
} VoxelVertex;

void World_Init(Chunk* chunk);
void World_Generate(Chunk* chunk, unsigned int seed);
BlockType World_GetBlock(Chunk* chunk, int x, int y, int z);
void World_SetBlock(Chunk* chunk, int x, int y, int z, BlockType type);
int World_IsSolid(Chunk* chunk, int x, int y, int z);

/* Like World_IsSolid, but used for player/mob movement collision instead of
 * face-culling: water doesn't block movement (so you can wade/swim into it)
 * even though it's not "air" for rendering purposes. */
int World_IsSolidForPhysics(Chunk* chunk, int x, int y, int z);

/* Builds a vertex list for all visible faces of the chunk (simple culling:
 * only emit a face if the neighboring block is air). Returns vertex count
 * and fills *outVerts with a linearAlloc'd buffer the caller must free with
 * World_FreeMesh (NOT plain free() - this lives in GPU-visible linear
 * memory so citro3d can hand its physical address straight to the GPU). */
int World_BuildMesh(Chunk* chunk, VoxelVertex** outVerts);
void World_FreeMesh(VoxelVertex* verts);

/* Color used to render each block type (used in World_BuildMesh) */
void Block_GetColor(BlockType type, float* r, float* g, float* b);
