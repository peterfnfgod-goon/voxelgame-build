#pragma once
#include <3ds.h>

/* --------------------------------------------------------------------------
 * Local wireless multiplayer (two 3DS units in the same room), using
 * libctru's UDS service - this is the 3DS's local ad-hoc wifi system, the
 * same kind of thing Download Play / local multiplayer uses.
 *
 * STATUS: this is a starting scaffold, not a finished networking layer.
 * It sets up the UDS connection and sends/receives a tiny fixed-size packet
 * (just position + facing) so two players can see roughly where each other
 * are. It does NOT yet sync: block edits, mob state, or inventory. Wiring
 * that in is mechanical but real work - happy to extend this once the base
 * position-sync is confirmed working on your actual hardware, since UDS
 * behavior can be picky about firmware/region and I can't test it from here.
 *
 * Internet multiplayer (different rooms/houses) is a different, bigger
 * project - it needs a server you host plus NAT/connection handling - not
 * covered here.
 * ------------------------------------------------------------------------*/

#define NET_MAX_PEERS 4
#define NET_CHANNEL   1
#define NET_APPDATA_SIZE 4

typedef struct {
    float x, y, z;
    float yaw;
} NetPlayerState;

typedef struct {
    int initialized;
    int isHost;
    udsNetworkStruct network;
    udsConnectionStatus connStatus;
    NetPlayerState peers[NET_MAX_PEERS];
    int peerCount;
} NetSession;

/* Starts hosting a local game ("Beacon" visible to other 3DS units running
 * this same homebrew). Returns 0 on success. */
int Net_Host(NetSession* session, const char* sessionName);

/* Scans for and joins the first available hosted session. Returns 0 on
 * success, -1 if none found within the timeout. */
int Net_Join(NetSession* session);

/* Sends this player's current state to all connected peers. Call once per
 * frame after updating the local player. */
void Net_SendState(NetSession* session, const NetPlayerState* localState);

/* Polls for incoming packets and updates session->peers[]. Call once per
 * frame before rendering other players. Returns number of peers updated. */
int Net_Poll(NetSession* session);

void Net_Shutdown(NetSession* session);
