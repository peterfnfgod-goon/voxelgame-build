# Voxel Survival (original 3DS homebrew scaffold)

This is a first-pass **source scaffold** for an original block-building/survival
game inspired by Minecraft, built for 3DS homebrew. It is not a copy of
Minecraft or any other existing game's code/assets/art.

## What's in this version

- **Blocks**: grass, dirt, stone, log, leaves, sand, plank, glass, water,
  coal ore, iron ore, snow - with a snowy biome and small lakes generated
  alongside the original hills/trees/caves-lite ore deposits.
- **Rendering**: the chunk mesh is now actually drawn on real GPU hardware
  via a compiled PICA200 vertex shader and `C3D_DrawArrays`, with the
  camera built from the player's live position/yaw/pitch each frame -
  previously this was a stubbed-out TODO.
- **Visual quality**: each cube face is shaded by direction (bright top,
  darker bottom, mid-tone sides) - a cheap "fake AO" trick that makes blocks
  read as 3D instead of flat-colored, without needing real lighting yet.
- **Mobs**: passive animals, a slow melee "shambler", an erratic flying
  hostile ("flyer"), and a tougher slow-hitting "brute" - all original AI,
  none copied from any existing game.
- **Crafting**: ore smelting (coal, iron ingot) and a sword added on top of
  the original plank/stick/pickaxe/axe recipes.
- **Local multiplayer scaffold**: `network.c`/`network.h` set up a basic
  UDS (3DS local wireless) host/join + position-sync. **Not wired into the
  main loop by default** and not tested on real hardware from here - see
  the multiplayer section below before relying on it.

## Honest status (please read before building)

This is a real starting point, not a finished game:

- World gen, blocks, inventory/crafting, day/night, and mob AI are plain C
  logic with no SDK-specific quirks - should compile cleanly once the
  toolchain is set up.
- **Rendering is now wired up**: `vshader.v.pica` compiles to a real
  PICA200 vertex shader (position * combined model-view-projection matrix,
  per-vertex color passed through), and `main.c` loads it, sets up the
  vertex attribute layout, builds the camera matrices from the player's
  position/yaw/pitch each frame, and calls `C3D_DrawArrays`. The chunk mesh
  buffer is allocated with `linearAlloc` (not `malloc`) since citro3d hands
  the GPU its buffers by physical address. **I still can't compile-test
  this against the real 3DS SDK headers from here**, so treat it as
  "should work based on the standard citro3d patterns" rather than
  "verified on hardware" - the most likely first-build issues are the
  uniform name in `vshader.v.pica` (`mvp`) not matching what
  `shaderInstanceGetUniformLocation` looks up if you rename anything, and
  face winding/culling (culling is currently disabled - `GPU_CULL_NONE` -
  specifically to sidestep an unverified winding order; flip it to
  `GPU_CULL_BACK_CCW` once you've confirmed faces look right and want the
  back-face cull for performance).
- No textures yet - blocks are flat-shaded colors per type (see "Visual
  quality" above). Adding textures means revisiting the vertex format
  (UVs), the shader (pass-through texcoord + a real texture binding in the
  texenv stage instead of the primary-color pass-through it does now), and
  `World_BuildMesh`'s per-face vertex data.
- **Multiplayer is a scaffold, not a working feature yet.** UDS networking
  on real 3DS hardware has device/firmware quirks I can't verify remotely,
  so treat `network.c` as a draft to debug against your actual two consoles,
  not something guaranteed to connect on the first try.
- The player has no gravity, jumping, or collision with the world yet -
  `Player_Move` only slides along X/Z based on yaw, and you can currently
  walk through blocks. Worth fixing before this feels like a real game.

## Multiplayer - what's realistic

- **Local wireless (same room, 2+ modded 3DS units)**: realistic, and what
  `network.c` scaffolds - it uses libctru's UDS service (the same local
  ad-hoc wifi system Download Play uses). Currently syncs only player
  position/facing between peers; block edits, mob state, and inventory are
  not synced yet (each player would see their own separate world). Extending
  it to sync block edits is the natural next step once basic connection is
  confirmed working.
- **Internet multiplayer (different locations)**: a meaningfully bigger,
  separate project - it needs a server you host and a real network protocol
  (state sync, reconciliation, etc.), not just a few more functions. Worth
  doing eventually, but treat it as its own milestone, not an add-on.

## What you need installed

1. **devkitPro** with the 3DS toolchain (devkitARM + libctru + citro3d + citro2d).
   Install via the devkitPro pacman installer for your OS, then make sure
   `DEVKITPRO` and `DEVKITARM` environment variables are set.
2. **bannertool** and **makerom** (both available via devkitPro's pacman, or
   from their GitHub releases) - these are what actually produce a `.cia`
   from the compiled `.elf`/`.3dsx`.

## Build steps

```sh
cd voxelgame
make
```

This produces `voxelgame.3dsx` (runnable directly via Homebrew Launcher on
your modded 3DS - no CIA needed for testing).

### Turning it into a .cia

A `.3dsx` is not a `.cia` - they're different homebrew formats. To get a
`.cia` you build the ELF into an actual NCCH/CIA with `makerom`:

```sh
makerom -f cia -o voxelgame.cia -DAPP_ENCRYPTED=false \
  -elf voxelgame.elf -rsf template.rsf -icon icon.icn -banner banner.bnr
```

You'll need a `template.rsf` (a standard makerom recipe file - the devkitPro
3ds-examples repo has one you can copy) plus a banner/icon, which bannertool
generates from a small PNG/audio you provide. This part is just mechanical
config, not game logic - happy to write the `.rsf` and a Makefile target
that does this automatically once you confirm devkitPro is installed and
the base game compiles for you.

## Controls (current scaffold)

- Circle Pad: look
- D-Pad: move
- A: break block player is looking at
- X: place currently selected inventory item (if it's a block)
- L / R: change selected inventory slot
- Y: craft (tries the first available recipe - demo only)
- START: quit

## Next steps I'd suggest

1. Get `make` producing `voxelgame.3dsx` with zero errors (fix any
   header/library path issues for your devkitPro version).
2. Run it on real hardware (or Citra) and confirm the world actually
   renders correctly - check face winding (try flipping `GPU_CULL_NONE` to
   `GPU_CULL_BACK_CCW` in `Render_Init` and see if anything disappears that
   shouldn't) and that the camera moves/looks the way Circle Pad/D-Pad input
   suggests it should.
3. Add player gravity, jumping, and collision against `World_IsSolid` -
   right now movement is a flat slide with no vertical physics.
4. Add textures (even simple 16x16 PNGs per block face) once flat-shaded
   rendering is confirmed working, for a bigger visual upgrade than shading
   alone.
5. Add the `template.rsf`/icon/banner so `make cia` works.
6. Once rendering works, test `network.c` on two real consoles and report
   back what happens - UDS connection issues are easiest to debug with
   actual error codes from real hardware.

Let me know how the first build goes - especially what the render actually
looks like on hardware - since that'll tell us whether the winding/culling
guess above was right or needs flipping.

